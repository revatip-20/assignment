from fastapi import APIRouter
from mcp_server.models.openai_backend import OpenAIBackend
from mcp_server.models.claude_backend import ClaudeBackend
from mcp_server.models.gemini_backend import GeminiBackend
from mcp_server.llm_router import LLMRouter

router = APIRouter()

# Initialize backend models
openai_backend = OpenAIBackend()
claude_backend = ClaudeBackend()
gemini_backend = GeminiBackend()
llm_router = LLMRouter(openai_backend, claude_backend, gemini_backend)

@router.post("/chat")
async def chat_with_ai(prompt: str):
    response = await llm_router.route_prompt(prompt)
    return {"response": response}
