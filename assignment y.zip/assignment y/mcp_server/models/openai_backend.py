import openai
from pydantic import BaseModel

class OpenAIBackend(BaseModel):
    api_key: str = "your_openai_api_key"

    def __init__(self):
        super().__init__()
        openai.api_key = self.api_key

    async def get_response(self, prompt: str) -> str:
        try:
            response = openai.Completion.create(
                model="text-davinci-003", prompt=prompt, max_tokens=150
            )
            return response.choices[0].text.strip()
        except Exception as e:
            return str(e)
