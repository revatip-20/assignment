from pydantic import BaseModel

class ClaudeBackend(BaseModel):
    api_key: str = "your_gemini_api_key"

    def __init__(self):
        super().__init__()

    async def get_response(self, prompt: str) -> str:
        # Placeholder for Claude API response (to be implemented)
        return "Claude API response: " + prompt
