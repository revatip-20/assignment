from pydantic import BaseModel

class GeminiBackend(BaseModel):
    api_key: str = "your_gemini_api_key"

    def __init__(self):
        super().__init__()

    async def get_response(self, prompt: str) -> str:
        # Placeholder for Gemini API response (to be implemented)
        return "Gemini API response: " + prompt
