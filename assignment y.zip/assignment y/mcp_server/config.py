# mcp_server/config.py

import os
from pydantic import BaseSettings

class Settings(BaseSettings):
    openai_api_key: str
    gemini_api_key: str
    claude_api_key: str
    default_model: str = "openai"  # Default model can be set here

    class Config:
        env_file = ".env"  # Load environment variables from .env file

settings = Settings()

def get_api_key(model_name: str) -> str:
    """Returns the API key for the selected model."""
    if model_name == "openai":
        return settings.openai_api_key
    elif model_name == "gemini":
        return settings.gemini_api_key
    elif model_name == "claude":
        return settings.claude_api_key
    else:
        raise ValueError("Unsupported model name")

def get_default_model() -> str:
    """Returns the default model configured in the environment."""
    return settings.default_model
