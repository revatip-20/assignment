from pydantic import BaseModel
from mcp_server.llm_router import LLMRouter

class ConversationalAgent(BaseModel):
    llm_router: LLMRouter

    async def converse(self, prompt: str) -> str:
        response = await self.llm_router.route_prompt(prompt)
        return response
