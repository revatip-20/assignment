from mcp_server.models.openai_backend import OpenAIBackend
from mcp_server.models.claude_backend import ClaudeBackend
from mcp_server.models.gemini_backend import GeminiBackend

class LLMRouter:
    def __init__(self, openai_backend: OpenAIBackend, claude_backend: ClaudeBackend, gemini_backend: GeminiBackend):
        self.openai_backend = openai_backend
        self.claude_backend = claude_backend
        self.gemini_backend = gemini_backend

    async def route_prompt(self, prompt: str) -> str:
        # Here, you could implement logic to route prompts based on conditions
        # For simplicity, let's route to OpenAI backend.
        return await self.openai_backend.get_response(prompt)
