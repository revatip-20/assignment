def clean_input_text(text: str) -> str:
    # Basic text cleaning function for input prompts
    return text.strip().lower()

def format_response_text(text: str) -> str:
    # Format the AI's response before sending it back to the user
    return f"Response: {text}"
