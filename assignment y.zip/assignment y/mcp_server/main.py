from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

# Define the model for expected request body
class ChatRequest(BaseModel):
    message: str

@app.post("/chat")
async def chat(request: ChatRequest):
    # Handle the incoming request
    message = request.message
    # Process the message...
    return {"response": f"Received message: {message}"}
