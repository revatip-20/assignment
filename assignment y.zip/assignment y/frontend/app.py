import gradio as gr
import requests

def chat_with_ai(prompt: str) -> str:
    response = requests.post("http://localhost:8000/chat", json={"prompt": prompt})
    return response.json().get("response", "Error")

iface = gr.Interface(fn=chat_with_ai, inputs="text", outputs="text", title="Conversational AI")

def send_message_to_backend(message):
    url = "http://localhost:8000/chat"
    data = {"message": message}  # Ensure 'message' is being sent
    response = requests.post(url, json=data)
    return response.json()

if __name__ == "__main__":
    iface.launch()
