# Conversational AI Application

This project implements a conversational AI system using FastAPI for the backend and Gradio for the frontend. It integrates multiple large language models (LLMs), including OpenAI, Claude, and Gemini, to provide an advanced, context-aware AI assistant. The system can process messages, handle context switching, and provide dynamic, intelligent responses.

## Project Structure

# === Directory Structure ===
# project/
# ├── mcp_server/
# │   ├── main.py
# │   ├── api.py
# │   ├── models/
# │   │   ├── openai_backend.py
# │   │   ├── claude_backend.py
# │   │   ├── gemini_backend.py
# │   │   └── llm_router.py
# │   ├── agent/
# │   │   └── conversational_agent.py
# │   └── utils/
# │       └── utils.py
# ├── frontend/
# │   └── app.py
# ├── .env
# ├── requirements.txt


## Installation

1. **Clone the repository:**

   ```bash
   git clone https://github.com/your-username/conversational-ai-app.git
   cd conversational-ai-app

2. **Install dependencies:**

You can install the required dependencies using pip:

pip install -r requirements.txt
Set up environment variables:

3. **Create a .env file in the root directory and add the necessary API keys for the LLMs.**
OPENAI_API_KEY=your_openai_api_key
CLAUDE_API_KEY=your_claude_api_key
GEMINI_API_KEY=your_gemini_api_key


4. **Running the Application**

Backend (FastAPI)
Run the FastAPI server:

uvicorn mcp_server.main:app --reload
The server will be running on http://127.0.0.1:8000.

Frontend (Gradio)
Start the Gradio interface:

python frontend/app.py
This will start the Gradio UI, and you can interact with the conversational AI directly through the web interface.

API Endpoints
/chat
This endpoint processes chat messages from the user and generates responses using one of the configured LLMs (OpenAI, Claude, or Gemini).

Method: POST

Request Body:

json
Copy code
{
  "message": "Hello, AI! How are you?"
}
Response:

json
Copy code
{
  "response": "Hello! I'm doing well, thank you for asking."
}
Project Features
LLM Support: Easily switch between OpenAI, Claude, and Gemini models based on the user's request.

Context-Aware: The system can maintain conversation context and provide relevant responses.

Real-time Chat: Gradio frontend provides an interactive interface for users to chat with the AI.

Backend API: FastAPI-based backend handles user requests and interacts with LLMs.

Testing the Application
To test the backend API directly, you can use tools like Postman or cURL.

Example using curl:

bash
curl -X 'POST' \
  'http://127.0.0.1:8000/chat' \
  -H 'Content-Type: application/json' \
  -d '{"message": "How can I help you today?"}'
Contributing
We welcome contributions! If you have suggestions or improvements, feel free to open a pull request.

License
This project is licensed under the MIT License.

Acknowledgments
OpenAI, Claude, and Gemini for providing powerful language models.

Gradio for an easy-to-use frontend interface.

FastAPI for building fast and efficient APIs.

Enjoy building and using the Conversational AI Application!

yaml

---

This version contains everything in one page and provides clear instructio